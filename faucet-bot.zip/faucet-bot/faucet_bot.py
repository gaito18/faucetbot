import datetime
from adb_wrapper import AdbWrapper, AdbFailException
from time import sleep

from PIL import Image

a = AdbWrapper()

a.device = '0546c489220892d6'
apps = ('ltc', 'btc', 'eth')
screen = 'screen.png'


def beep():
    import time
    import sys

    for i in range(500):
        sys.stdout.write('\r\a{i}'.format(i=i))
        time.sleep(0.1)
    sys.stdout.write('\n')


def keyevent(keycode):
    a.shell('input keyevent ' + keycode)


def switch_app(app):
    a.shell('am start -n com.amtfaucet.' + app + '/.MainActivity')


def take_screenshot(filename):
    a.shell('screencap -p /sdcard/screen.png')
    a.pull('/sdcard/screen.png', filename)


def get_pix(x, y, filename):
    im = Image.open(filename)
    pix = im.load()
    return pix[x, y]


def tap(x, y):
    a.shell('input tap ' + str(x) + ' ' + str(y))


def claim(app):
    take_screenshot(screen)
    pix = get_pix(610, 552, screen)
    if pix == (30, 30, 31, 255):
        switch_app(app)
        tap(534, 575)
        return True
    else:
        return False


def fast_cycle(app):
    switch_app(app)
    sleep(2)
    for i in range(90):
        switch_app(app)
        if claim(app):
            break


def main():
    claims = 0
    a.shell('settings put system screen_brightness 1')

    while True:
        for app in apps:
            try:
                keyevent('KEYCODE_WAKEUP')
                fast_cycle(app)
                if app == apps[0]: claim_time = datetime.datetime.now()
                keyevent('KEYCODE_POWER')
            except AdbFailException:
                beep()
            sleep(10)
        claims += 1
        print('Claims:', claims)
        now = datetime.datetime.now()
        delta = now - claim_time
        sleep(abs(280 - delta.seconds))


main()
